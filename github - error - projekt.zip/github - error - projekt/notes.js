const chalk = require('chalk');
const fs = require('fs');
console.log(chalk.bgBlackBright.greenBright('Starting notes.js'));

let fetchNotes = () => {
    try{
        let notesString = fs.readFileSync('notes-data.json') // liest den string aus
        notes = JSON.parse(notesString); // wandelt ihn in ein Objekt
    }catch(err){
        return []
    }
}
let saveNotes = (notes) => {
    fs.writeFileSync('notes-data.json',JSON.stringify(notes));
}
let addNotes = (title, body) => {
    let notes = fetchNotes();
    let note = {
        title,
        body
    };
    
    let duplicateNotes = notes.filter((note) => note.title === title); //true
    
    if (duplicateNotes.length === 0){
        notes.push(note);
        saveNotes(notes);
    }else{
        console.log(chalk.red('You cant duplicate notes!'));
    }
};
let getList = (title) => {
    console.log('list:', title);
};
let readNotes = (title) => {
    console.log('read:', title);
};
let removeNotes = (title) => {
    console.log('remove:', title);
};

module.exports = {
    addNotes,
    getList,
    readNotes,
    removeNotes
};
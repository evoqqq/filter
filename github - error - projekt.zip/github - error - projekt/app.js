const fs = require('fs');
const _ = require('lodash');
const chalk = require('chalk');
const yargs = require('yargs');

const notes = require('./notes.js');
console.log(chalk.bgBlackBright.greenBright('Starting app.js'));

const argv = yargs.argv; // wurde mit yargs definiert (additional command line argument => argv)
let command = argv._[0]; // for adding the argv "COMMANDS" 
console.log('yargs: ', argv);
console.log('command: ', command);


if (command === 'add') {
    notes.addNotes(argv.title, argv.body);
} else if (command === 'list') {
    notes.getList(argv.title);
} else if (command === 'read') {
    notes.readNotes(argv.title);
} else if (command === 'remove') {
    notes.removeNotes(argv.title);
} else {
    console.log('error')
}